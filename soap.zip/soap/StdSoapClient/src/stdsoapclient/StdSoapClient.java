/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stdsoapclient;

import sevies.Student;

/**
 *
 * @author User
 */
public class StdSoapClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Student std = findByID(1);
       System.out.println(std.getId()+" "+std.getName()+" "+std.getGpa());
       
       Student stdInsert = insert(9,"araika",3.6);
       System.out.println(stdInsert.getId()+" "+stdInsert.getName()+" "+stdInsert.getGpa());
       
       Student stdUpdate = update(1,"wanhgi",3.7);
       System.out.println(stdUpdate.getId()+" "+stdUpdate.getName()+" "+stdUpdate.getGpa());
       
       Student stdDelete = delete(3);
       //System.out.println(stdDelete.getId()+" "+stdDelete.getName()+" "+stdDelete.getGpa());
    }

    private static Student findByID(int id) {
        sevies.StdWebService_Service service = new sevies.StdWebService_Service();
        sevies.StdWebService port = service.getStdWebServicePort();
        return port.findByID(id);
    }

    private static Student insert(int id, java.lang.String name, double gpa) {
        sevies.StdWebService_Service service = new sevies.StdWebService_Service();
        sevies.StdWebService port = service.getStdWebServicePort();
        return port.insert(id, name, gpa);
    }

    private static Student update(int id, java.lang.String name, double gpa) {
        sevies.StdWebService_Service service = new sevies.StdWebService_Service();
        sevies.StdWebService port = service.getStdWebServicePort();
        return port.update(id, name, gpa);
    }

    private static Student delete(int id) {
        sevies.StdWebService_Service service = new sevies.StdWebService_Service();
        sevies.StdWebService port = service.getStdWebServicePort();
        return port.delete(id);
    }
    
}
