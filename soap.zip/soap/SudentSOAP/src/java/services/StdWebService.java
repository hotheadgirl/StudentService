/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Student;

/**
 *
 * @author User
 */
@WebService(serviceName = "StdWebService")
public class StdWebService {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("SudentSOAPPU");

    /**
     * This is a sample web service operation
     */

    @WebMethod(operationName = "findByID")
    public Student findByID(@WebParam(name = "id") int id) {
        EntityManager em = emf.createEntityManager();
        Student std = em.find(Student.class, id);
        return std;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "insert")
    public Student insert(@WebParam(name = "id") int id, @WebParam(name = "name") String name, @WebParam(name = "gpa") double gpa) {
        EntityManager em = emf.createEntityManager();
        Student std = new Student(id,name,gpa);
        em.getTransaction().begin();
        try {
            em.persist(std);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
        return std;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "delete")
    public Student delete(@WebParam(name = "id") int id) {
        EntityManager em = emf.createEntityManager();
        Student std = em.find(Student.class, id);
        em.getTransaction().begin();
        try {
            em.remove(std);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
        return std;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "update")
    public Student update(@WebParam(name = "id") int id, @WebParam(name = "name") String name, @WebParam(name = "gpa") double gpa) {
       EntityManager em = emf.createEntityManager();
       Student std = em.find(Student.class, id);
       std.setName(name);
       std.setGpa(gpa);
       em.getTransaction().begin();
       try {
           em.persist(std);
           em.getTransaction().commit();
       } catch (Exception e) {
           e.printStackTrace();
           em.getTransaction().rollback();
       } finally {
           em.close();
       }
        return std;
    }
    
}
